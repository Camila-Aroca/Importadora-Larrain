# Importadora-Larrain
Importante:
***Ver página de index.html e imagen subida al repositorio como referencias visuales. Usé la button class btn-danger de bootstrap por el color rojo y colores neutros para fondos y letras (grises oscuros, grises claros y blancos, ver index.html para referencia.)
***Agregar todas las imagenes que usen a la carpeta assests/img para mantener todos los path uniformes
***El path del logo principal de la tienda es assests/img/logo_gato.png
Vistas por hacer:
1. REGISTRO DE PERFIL EN EL SISTEMA: 
Esta es la vista en la que el cliente debe poder crear su cuenta. Esto se puede hacer con componentes de la vista de inicio.html (inicio de sesión) y formulario_producto.html (esta es la vista que se creó para subir productos, la parte para subir fotos aún no está funcional pero los input sí). 
2. REALIZAR PEDIDOS: 
La idea es que esta sea una vista en la que el cliente pueda ingresar la info necesaria para completar un pedido (por ej. dirección, opción de envío y datos personales porque la info de pago ya está incluida en la vista del carrito).
3. INICIO SESIÓN (CLIENTE, SUPERVISOR Y ADMINISTRADOR IMPORTADORA):
Se crea a partir de la modificación de la vista inicio.html
5. EXPLORACIÓN DE PRODUCTO:
Se puede hacer simplemente modificando la vista shop_single.html. Al hacer click en un botón que diga "Agregar producto a carrito" o algo similar debería dirigir a carrito.html.
6. AGREGAR PRODUCTOS A CARRITO:
Modificar texto, imágenes y colores de carrito.html
7. CERRAR SESIÓN EN EL SISTEMA (CLIENTE, SUPERVISOR Y ADMINISTRADOR IMPORTADORA):
Puede hacerse a partir de inicio de sesión
8. COMUNICACIÓN ENTRE AGENTE Y SUPERVISOR:
Esta es la misma vista para el agente y para el supervisor con el texto cambiado, se puede crear una vista dividida en 2, una sección para escribir un mensaje y un inbox
9. ACTUALIZAR LISTA DE OFERTAS:
Se debe crear de 0
10. SUBIR NUEVOS PRODUCTOS:
Se puede hacer modificando formulario_producto.html
11. CONSULTAR HISTORIAL DE COMPRAS Y VENTAS:
Se debe hacer de 0
13. REVISAR SOLICITUDES DE CLIENTES:
Se debe hacer de 0
